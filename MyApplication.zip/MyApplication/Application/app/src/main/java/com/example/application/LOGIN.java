package com.example.application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LOGIN extends AppCompatActivity {
    Button btnsignups,btnsignins;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnsignups = (Button) findViewById(R.id.button3);
        btnsignins = (Button) findViewById(R.id.button2);

        btnsignups.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signuppage();
            }
        });
    }

     public void signuppage(){
         Intent i = new Intent(this, SIGNUP.class);
         startActivity(i);
     }

}
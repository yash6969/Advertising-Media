package com.example.application;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.ExecutionException;

public class SIGNUP extends AppCompatActivity {

    EditText editTextname1,edittextaddress2,editTextphoneno3,editTextdirection4,editTextservice5,edittextemail,edittextpassword;
    Button btnsignup, btnsignin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        editTextname1 = (EditText) findViewById(R.id.editText1);
        edittextaddress2 = (EditText) findViewById(R.id.editText2);
        editTextphoneno3 = (EditText) findViewById(R.id.editText3);
        editTextdirection4 = (EditText) findViewById(R.id.editText4);
        editTextservice5 = (EditText) findViewById(R.id.editText5);
        edittextemail = (EditText) findViewById(R.id.editText6);
        edittextpassword = (EditText) findViewById(R.id.editText7);

        btnsignup = (Button) findViewById(R.id.button);
        btnsignin = (Button) findViewById(R.id.button3);

        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registrationtodatabase();
            }
        });

    }
    public Connection connectionclass() {
        Connection conn = null;
        String ip = "10.100.160.230", port="1433", username="sa", password="yash", databasename="AdvertiserRegistration";

        StrictMode.ThreadPolicy tp = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(tp);

        try {
           Class.forName("net.sourceforge.jtds.jdbc.Driver");
           String connectionurl = "jdbc:jtds:sqlserver://"+ip+":"+port+";databasename="+databasename+";username="+username+";password="+password+";";
           conn = DriverManager.getConnection(connectionurl);
        }
        catch (Exception exception){
            Log.e("Error", exception.getMessage());
        }
        return conn;
    }

    public void registrationtodatabase(){
        String name,address,phoneno,direction,service,emailid,password;


        name = editTextname1.getText().toString();
        address = edittextaddress2.getText().toString();
        phoneno = editTextphoneno3.getText().toString();
        direction = editTextdirection4.getText().toString();
        service = editTextservice5.getText().toString();
        emailid = edittextemail.getText().toString();
        password = edittextpassword.getText().toString();

        int phone = Integer.parseInt(phoneno);
        int directions = Integer.parseInt(direction);

        Connection connection = connectionclass();

        try {

            if(connection != null){
                String sqlinsert = "Insert into company_reg values ('"+name+"','"+address+"','"+phone+"','"+direction+"','"+emailid+"','"+password+"')";
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(sqlinsert);
            }

        } catch (Exception exception){
            Log.e("Error", exception.getMessage());
        }
    }

    public void loginpage(){

    }


}